package com.example.pizzaorder_pargat;

import javafx.collections.FXCollections;
import javafx.collections.ObservableList;
import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.fxml.Initializable;
import javafx.scene.control.*;
import javafx.scene.control.cell.PropertyValueFactory;

import java.net.URL;
import java.sql.*;
import java.util.ResourceBundle;

public class HelloController implements Initializable {

    @FXML
    private TextField customerNameField;
    @FXML
    private TextField mobileNumberField;
    @FXML
    private CheckBox sizeXL;
    @FXML
    private CheckBox sizeL;
    @FXML
    private CheckBox sizeM;
    @FXML
    private CheckBox sizeS;
    @FXML
    private TextField toppingsField;
    @FXML
    private Button createButton;
    @FXML
    private Button readButton;
    @FXML
    private Button updateButton;
    @FXML
    private Button deleteButton;
    @FXML
    private TableView<PizzaOrder> pizzaOrdersTable;
    @FXML
    private TableColumn<PizzaOrder, Integer> orderIdColumn;
    @FXML
    private TableColumn<PizzaOrder, String> customerNameColumn;
    @FXML
    private TableColumn<PizzaOrder, String> mobileNumberColumn;
    @FXML
    private TableColumn<PizzaOrder, String> pizzaSizeColumn;
    @FXML
    private TableColumn<PizzaOrder, Integer> numberOfToppingsColumn;
    @FXML
    private TableColumn<PizzaOrder, Double> totalBillColumn;
    @FXML
    private TextField uid;

    private ObservableList<PizzaOrder> pizzaOrderList = FXCollections.observableArrayList();

    @Override
    public void initialize(URL url, ResourceBundle resourceBundle) {
        // Initialize table columns
        orderIdColumn.setCellValueFactory(new PropertyValueFactory<>("orderId"));
        customerNameColumn.setCellValueFactory(new PropertyValueFactory<>("customerName"));
        mobileNumberColumn.setCellValueFactory(new PropertyValueFactory<>("mobileNumber"));
        pizzaSizeColumn.setCellValueFactory(new PropertyValueFactory<>("pizzaSize"));
        numberOfToppingsColumn.setCellValueFactory(new PropertyValueFactory<>("numberOfToppings")); // Corrected here
        totalBillColumn.setCellValueFactory(new PropertyValueFactory<>("totalBill"));

        // Set table data
        pizzaOrdersTable.setItems(pizzaOrderList);

        // Populate initial data
        populateTable();
    }

    @FXML
    private void createButton(ActionEvent event) {
        String customerName = customerNameField.getText();
        String mobileNumber = mobileNumberField.getText();
        String pizzaSize = getPizzaSize();
        int numberOfToppings = Integer.parseInt(toppingsField.getText());
        double totalBill = calculateTotalBill(pizzaSize, numberOfToppings);

        // Insert into database
        String jdbcUrl = "jdbc:mysql://localhost:3306/pizzaorder";
        String dbUser = "root";
        String dbPassword = "";

        try (Connection connection = DriverManager.getConnection(jdbcUrl, dbUser, dbPassword)) {
            String query = "INSERT INTO pizza_order (CustomerName, MobileNumber, PizzaSize, NumberOfToppings, TotalBill) VALUES (?, ?, ?, ?, ?)";
            PreparedStatement preparedStatement = connection.prepareStatement(query);
            preparedStatement.setString(1, customerName);
            preparedStatement.setString(2, mobileNumber);
            preparedStatement.setString(3, pizzaSize);
            preparedStatement.setInt(4, numberOfToppings);
            preparedStatement.setDouble(5, totalBill);

            preparedStatement.executeUpdate();
            populateTable(); // Refresh table data
        } catch (SQLException e) {
            e.printStackTrace();
        }
    }

    @FXML
    private void readButton(ActionEvent event) {
        populateTable(); // Refresh table data
    }

    @FXML
    private void updateButton(ActionEvent event) {
        int orderId = Integer.parseInt(uid.getText());
        String customerName = customerNameField.getText();
        String mobileNumber = mobileNumberField.getText();
        String pizzaSize = getPizzaSize();
        int numberOfToppings = Integer.parseInt(toppingsField.getText());
        double totalBill = calculateTotalBill(pizzaSize, numberOfToppings);

        // Update database record
        String jdbcUrl = "jdbc:mysql://localhost:3306/pizzaorder";
        String dbUser = "root";
        String dbPassword = "";

        try (Connection connection = DriverManager.getConnection(jdbcUrl, dbUser, dbPassword)) {
            String query = "UPDATE pizza_order SET CustomerName=?, MobileNumber=?, PizzaSize=?, NumberOfToppings=?, TotalBill=? WHERE OrderId=?";
            PreparedStatement preparedStatement = connection.prepareStatement(query);
            preparedStatement.setString(1, customerName);
            preparedStatement.setString(2, mobileNumber);
            preparedStatement.setString(3, pizzaSize);
            preparedStatement.setInt(4, numberOfToppings);
            preparedStatement.setDouble(5, totalBill);
            preparedStatement.setInt(6, orderId);

            preparedStatement.executeUpdate();
            populateTable(); // Refresh table data
        } catch (SQLException e) {
            e.printStackTrace();
        }
    }

    @FXML
    private void deleteButton(ActionEvent event) {
        int orderId = Integer.parseInt(uid.getText());

        // Delete record from database
        String jdbcUrl = "jdbc:mysql://localhost:3306/pizzaorder";
        String dbUser = "root";
        String dbPassword = "";

        try (Connection connection = DriverManager.getConnection(jdbcUrl, dbUser, dbPassword)) {
            String query = "DELETE FROM pizza_order WHERE OrderId=?";
            PreparedStatement preparedStatement = connection.prepareStatement(query);
            preparedStatement.setInt(1, orderId);

            preparedStatement.executeUpdate();
            populateTable(); // Refresh table data
        } catch (SQLException e) {
            e.printStackTrace();
        }
    }

    private void populateTable() {
        pizzaOrderList.clear();

        // Fetch data from database
        String jdbcUrl = "jdbc:mysql://localhost:3306/pizzaorder";
        String dbUser = "root";
        String dbPassword = "";

        try (Connection connection = DriverManager.getConnection(jdbcUrl, dbUser, dbPassword)) {
            String query = "SELECT * FROM pizza_order";
            Statement statement = connection.createStatement();
            ResultSet resultSet = statement.executeQuery(query);

            while (resultSet.next()) {
                int orderId = resultSet.getInt("OrderId");
                String customerName = resultSet.getString("CustomerName");
                String mobileNumber = resultSet.getString("MobileNumber");
                String pizzaSize = resultSet.getString("PizzaSize");
                int numberOfToppings = resultSet.getInt("NumberOfToppings");
                double totalBill = resultSet.getDouble("TotalBill");

                pizzaOrderList.add(new PizzaOrder(orderId, customerName, mobileNumber, pizzaSize, numberOfToppings, totalBill));
            }
        } catch (SQLException e) {
            e.printStackTrace();
        }
    }

    private String getPizzaSize() {
        if (sizeXL.isSelected()) {
            return "XL";
        } else if (sizeL.isSelected()) {
            return "L";
        } else if (sizeM.isSelected()) {
            return "M";
        } else if (sizeS.isSelected()) {
            return "S";
        }
        return "";
    }

    public double calculateTotalBill(String size, int toppings) {
        double baseCost = 0.0;
        switch (size) {
            case "XL":
                baseCost = 15.00;
                break;
            case "L":
                baseCost = 12.00;
                break;
            case "M":
                baseCost = 10.00;
                break;
            case "S":
                baseCost = 8.00;
                break;
            default:
                break;
        }
        double totalCost = baseCost + (toppings * 1.50);
        double hst = totalCost * 0.15; // Assuming HST (Harmonized Sales Tax)
        return totalCost + hst;
    }
}