module com.example.pizzaorder_pargat {
    requires javafx.controls;
    requires javafx.fxml;

    requires com.almasb.fxgl.all;
    requires java.sql;

    opens com.example.pizzaorder_pargat to javafx.fxml;
    exports com.example.pizzaorder_pargat;
}