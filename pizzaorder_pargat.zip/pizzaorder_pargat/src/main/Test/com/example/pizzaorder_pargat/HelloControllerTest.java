package com.example.pizzaorder_pargat;

import org.junit.jupiter.api.Test;

import static org.junit.jupiter.api.Assertions.assertEquals;

public class HelloControllerTest {

    @Test
    public void testCalculateTotalBillXLSize() {
        HelloController controller = new HelloController();
        double totalBill = controller.calculateTotalBill("XL", 2);
        assertEquals(19.50, totalBill, 0.01); // Expected total bill for XL size with 2 toppings
    }

    @Test
    public void testCalculateTotalBillMSize() {
        HelloController controller = new HelloController();
        double totalBill = controller.calculateTotalBill("M", 3);
        assertEquals(14.25, totalBill, 0.01); // Expected total bill for M size with 3 toppings
    }

    @Test
    public void testCalculateTotalBillNoToppings() {
        HelloController controller = new HelloController();
        double totalBill = controller.calculateTotalBill("S", 0);
        assertEquals(9.20, totalBill, 0.01); // Expected total bill for S size with no toppings
    }

    @Test
    public void testCalculateTotalBillInvalidSize() {
        HelloController controller = new HelloController();
        double totalBill = controller.calculateTotalBill("InvalidSize", 2);
        assertEquals(0.0, totalBill, 0.01); // Expected total bill when size is invalid
    }
}
